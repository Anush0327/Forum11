package com.prodapt.learningspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
